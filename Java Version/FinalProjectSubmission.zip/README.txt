File: README.txt
Author: Amanda Hoesman-Foley
Project: TheEmeraldRuins.java
Date: 11.14.16
*****************************

Explanation: This program works as a choose your own adventure game. 
While not being too complex, there are many branching paths determined by the user. 
The program recieves user input to determine what path to take, and calls upon various methods to output
the results or execute a calculation. 

Installation/Configuration Details: No extra setup is required.

Operating Instructions: Simply run the program and follow the prompts on-screen to complete the game.

Known bugs: The program accounts for most errors. If the user inputs any string other than what is
expected, or other inputs, the program will output a message to the user and end using a 
System.exit statement.

Contact information -- author's email: hoesmanfoa@cwu.edu.
********************************************************************************************************